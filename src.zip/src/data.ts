export const entries = [
    {
        id: '1',
        title: 'First Entry',
        description: 'This is the FIRST ENTRY'
    },
    {
        id: '2',
        title: 'Second Entry',
        description: 'This is the SECOND ENTRY'
    },
    {
        id: '3',
        title: 'Third Entry',
        description: 'This is the THIRD ENTRY'
    },

];